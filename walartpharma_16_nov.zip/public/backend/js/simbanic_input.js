
jQuery(function(){
    jQuery('#dob').datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd-mm-yy',
        yearRange: "1960:2010",
    });
});

jQuery(function(){
    jQuery('#marriage_anni').datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd-mm-yy',
        yearRange: "1940:",
    });
});

jQuery(function(){
    jQuery('#nominee_dob').datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd-mm-yy',
        yearRange: "1960:2010",
    });
});