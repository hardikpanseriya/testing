<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['simba_list_limit'] = 10;

$config['simba_sponsorid_limit'] = 10;

$config['simba_sponsor_level_restriction'] = 5;

$config['simba_customer_id_unique_digit'] = 4;

$config['simba_customer_id_state_code'] = 3;

$config['simba_customer_id_start_value'] = 1051;