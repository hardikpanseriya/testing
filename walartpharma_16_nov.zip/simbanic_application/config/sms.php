<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

	/*SMS CONFIG*/
	$config['sms']['method'] = 'sms';
	$config['sms']['api_key'] = 'A2a58dc64954c4fb6c539ffc8777beae5';
	$config['sms']['sender_id'] = 'WALART';
	$config['sms']['api_url'] = 'http://trans.magicsms.co.in/api/v3';

?>