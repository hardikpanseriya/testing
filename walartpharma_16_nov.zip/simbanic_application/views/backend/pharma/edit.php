<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">
				Pharma Form
			</div>
			<div class="panel-body">
				<?php $this->load->view(BACKEND . '/pharma/form'); ?>
			</div>
		</div>
	</div>
</div>