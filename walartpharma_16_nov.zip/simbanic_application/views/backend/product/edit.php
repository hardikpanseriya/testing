<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">
				Product Form
			</div>
			<div class="panel-body simba_customer_form">
				<?php $this->load->view(BACKEND . '/product/form'); ?>
			</div>
		</div>
	</div>
</div>

<?php $this->load->view(BACKEND . '/common/footer'); ?>