	<table width="100%" style="margin: 5px 0px 5px 0px; border: 0.1mm solid #888888;">
		<tr>
			<td width="70%" style="padding: 5px;">
				
			</td>
			<td align="right" width="30%" style="padding: 5px;">
				<b>For, WALARTPHARMACEUTICAL CO .</b>
			</td>
		</tr>

		<tr>
			<td width="60%" style="padding: 5px;">
				<span style="margin-bottom: 5px;">* - Inclusive All Taxes</span>
				<ol style="padding-left: 16px;">
					<li style="margin-bottom: 5px;">Goods are despatched at customer risk. Responsibility cases
entirely as soon as the goods leave our stores.</li>
					<li style="margin-bottom: 5px;">Please Check Up weight & condition before acceptance of the
parcel in case of doubt open delivery should be insisted upon .</li>
					<li style="margin-bottom: 5px;">Claries for loss should be submitted to the carriers .</li>
					<li style="margin-bottom: 5px;">18% interest will be charged if not paid within 21 days from
the date of L.R.</li>
				</ol>
			</td>
			<td align="center" width="40%" style="padding: 5px; vertical-align: middle;">
				<b>AUTHORISED SIGNATORY</b>
			</td>
		</tr>
	</table>