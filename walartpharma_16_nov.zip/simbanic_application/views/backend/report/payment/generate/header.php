	
		<table width="100%" style="margin-bottom: 10px;">
			<tr>
				<td width="50%" style="color:#0000BB;">
					<span style="font-weight: bold; font-size: 14pt;">WALART PHARMACEUTICAL CO.</span><br />
					SF - 63, 3RD FLOOR<br />
					SHRIMAD BHAVAN<br />
					RAJKOT - 360001<br />
					<span style="font-size: 15pt;">&#9742;</span> 97241 54433
				</td>
			</tr>
		</table>
	
	